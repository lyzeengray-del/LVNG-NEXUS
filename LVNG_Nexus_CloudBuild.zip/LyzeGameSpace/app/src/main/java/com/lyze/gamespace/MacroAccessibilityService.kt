package com.lyze.gamespace

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

data class MacroStep(val x: Float, val y: Float, val delayMs: Long)

class MacroAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: MacroAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun tap(x: Float, y: Float, onDone: (() -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { onDone?.invoke() }
            override fun onCancelled(gestureDescription: GestureDescription?) { onDone?.invoke() }
        }, null)
    }
}

object MacroRunner {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    fun stop() { running = false; handler.removeCallbacksAndMessages(null) }
    fun play(context: android.content.Context, steps: List<MacroStep>) {
        stop()
        running = true
        val service = MacroAccessibilityService.instance ?: run { running = false; return }
        fun runAt(index: Int) {
            if (!running || index >= steps.size) { running = false; return }
            val step = steps[index]
            service.tap(step.x, step.y) {
                handler.postDelayed({ runAt(index + 1) }, step.delayMs)
            }
        }
        runAt(0)
    }
}

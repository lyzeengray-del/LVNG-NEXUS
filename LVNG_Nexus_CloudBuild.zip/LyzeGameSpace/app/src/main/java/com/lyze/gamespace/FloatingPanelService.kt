package com.lyze.gamespace

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var panel: android.view.View? = null
    override fun onCreate() {
        super.onCreate()
        val channelId = "lyze_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Gaming panel", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("Lyze Game Space").setContentText("Floating panel aktif").setSmallIcon(android.R.drawable.ic_media_play).build()
        else Notification.Builder(this).setContentTitle("Lyze Game Space").setContentText("Floating panel aktif").setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, notification)
        showPanel()
    }
    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xEE10243D.toInt())
        }
        val title = TextView(this).apply { text = "LYZE • GAME"; setTextColor(0xFFFFFFFF.toInt()); textSize = 12f }
        val run = Button(this).apply {
            text = "OPEN MACRO"
            setOnClickListener { startActivity(Intent(this@FloatingPanelService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
        val close = Button(this).apply { text = "CLOSE PANEL"; setOnClickListener { stopSelf() } }
        box.addView(title); box.addView(run); box.addView(close)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 180 }
        panel = box
        wm.addView(box, params)
    }
    override fun onDestroy() { panel?.let { runCatching { wm.removeView(it) } }; panel = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

package com.lyze.gamespace

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071426)
private val Panel = Color(0xFF10243D)
private val Blue = Color(0xFF35A7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameSpaceApp() }
    }
}

@Composable
fun GameSpaceApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var macroName by remember { mutableStateOf("macro baru") }
    var delay by remember { mutableStateOf("500") }
    var x by remember { mutableStateOf("540") }
    var y by remember { mutableStateOf("960") }
    var repeat by remember { mutableStateOf("1") }
    var status by remember { mutableStateOf("belum ada macro dijalankan") }
    var steps by remember { mutableStateOf(listOf<MacroStep>()) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.TouchApp, null) }, label = { Text("macro") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Tune, null) }, label = { Text("tools") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF102B4A), Navy))).padding(padding).padding(18.dp)) {
                Text("LVNG", color = Blue, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("nexus", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(18.dp))
                when (tab) {
                    0 -> {
                        InfoCard("gaming dashboard", "panel kontrol tambahan untuk game android")
                        Spacer(Modifier.height(12.dp))
                        InfoCard("macro engine", "${steps.size} langkah tersimpan di editor saat ini")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            if (!Settings.canDrawOverlays(context)) {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                            } else {
                                context.startForegroundService(Intent(context, FloatingPanelService::class.java))
                                status = "floating panel diminta untuk dijalankan"
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Layers, null); Spacer(Modifier.width(8.dp)); Text("aktifkan floating panel") }
                        Text(status, color = Color.LightGray, fontSize = 12.sp)
                    }
                    1 -> {
                        Text("macro editor", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(macroName, { macroName = it }, label = { Text("nama macro") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(x, { x = it }, label = { Text("posisi x") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(y, { y = it }, label = { Text("posisi y") }, modifier = Modifier.weight(1f))
                        }
                        OutlinedTextField(delay, { delay = it }, label = { Text("jeda setelah tap (ms)") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val sx = x.toFloatOrNull(); val sy = y.toFloatOrNull(); val d = delay.toLongOrNull()
                            if (sx != null && sy != null && d != null && d >= 0) {
                                steps = steps + MacroStep(sx, sy, d)
                                status = "langkah ditambahkan"
                            } else status = "isi koordinat dan jeda dengan angka yang valid"
                        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text(" tambah langkah tap") }
                        Text("langkah macro", color = Color.White, fontWeight = FontWeight.Bold)
                        LazyColumn(Modifier.weight(1f)) {
                            items(steps) { step -> Text("tap x=${step.x.toInt()} y=${step.y.toInt()} • jeda ${step.delayMs} ms", color = Color.LightGray, modifier = Modifier.padding(vertical = 5.dp)) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (steps.isEmpty()) status = "tambahkan langkah dulu"
                                else if (MacroAccessibilityService.instance == null) {
                                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                    status = "aktifkan Lyze Game Space di menu aksesibilitas"
                                } else {
                                    MacroRunner.play(context, steps)
                                    status = "macro dijalankan"
                                }
                            }, modifier = Modifier.weight(1f)) { Text("jalankan") }
                            OutlinedButton(onClick = { steps = emptyList(); status = "editor dibersihkan" }) { Text("hapus") }
                        }
                        Text(status, color = Color.LightGray, fontSize = 12.sp)
                    }
                    else -> {
                        InfoCard("izin overlay", "dibutuhkan agar panel bisa tampil di atas game.")
                        Button(onClick = { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }, modifier = Modifier.fillMaxWidth()) { Text("buka izin overlay") }
                        Spacer(Modifier.height(8.dp))
                        InfoCard("izin accessibility", "dibutuhkan untuk mengirim gesture macro setelah lu mengaktifkannya sendiri.")
                        Button(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("buka pengaturan accessibility") }
                        Spacer(Modifier.height(8.dp))
                        Text("kompatibilitas: android 8+; ditargetkan untuk android 14–16. izin bisa berbeda antar merek hp.", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Color.LightGray, fontSize = 13.sp)
        }
    }
}
